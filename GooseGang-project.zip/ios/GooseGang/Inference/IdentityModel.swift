import Foundation

/// 身份概率推理模型（贝叶斯对数赔率累加）。
///
/// 原理：P(身份|证据) ∝ P(身份) × Π P(证据|身份)
/// 取对数后变成加法：log-odds = 先验 + Σ 行为证据增量，最后 softmax 归一化。
///
/// 行为证据→增量由「鹅鸭杀游戏逻辑」推导的可解释规则表给出，
/// 所有权重均为可调参数（见 ARCHITECTURE.md），可在设置中调整。
struct IdentityModel {
    /// 先验对数赔率：默认按常见 10 人局（5 鹅 / 2 鸭 / 3 中立）近似
    static let prior: [GameIdentity: Double] = [
        .goose: log(0.50),
        .duck: log(0.20),
        .neutral: log(0.30),
    ]

    static func initialScores() -> IdentityScores {
        IdentityScores(goose: prior[.goose] ?? 0,
                       duck: prior[.duck] ?? 0,
                       neutral: prior[.neutral] ?? 0)
    }

    /// 应用证据增量（原地更新）
    static func apply(_ delta: IdentityDelta, to scores: inout IdentityScores) {
        scores.goose += delta.goose
        scores.duck += delta.duck
        scores.neutral += delta.neutral
    }

    // MARK: - 特征 → 证据增量（核心规则表）

    /// 疑似做任务（静止于任务点）
    static func taskDwellDelta(seconds: Double) -> IdentityDelta {
        let strength = min(1.0, seconds / 6.0)
        return IdentityDelta(goose: 1.2 * strength,
                             duck: -0.9 * strength,
                             neutral: -0.3 * strength)
    }

    /// 高速绕路（速度快 + 路径蜿蜒度低 → 无目的游走，鸭倾向）
    static func wanderDelta(speed: Double, meandering: Double) -> IdentityDelta {
        // 速度以“归一化画面宽度/秒”计；经验阈值：>0.06 为快
        guard speed > 0.06 else { return .zero }
        let fast = min(1.0, (speed - 0.06) / 0.10)
        let winding = (1 - meandering)              // 0 直线，1 全绕
        let strength = min(1.0, fast * (0.6 + 0.4 * winding))
        return IdentityDelta(duck: 0.8 * strength,
                             goose: -0.5 * strength,
                             neutral: 0.1 * strength)
    }

    /// 尾随他人
    static func tailDelta() -> IdentityDelta {
        IdentityDelta(duck: 0.9, goose: -0.6, neutral: 0.1)
    }

    /// 尸体事件
    ///  - 案发瞬间在场：强鸭信号（刚刀完 / 来查看尸体）
    ///  - 尸体旁围观停留：鹅/中立倾向（好人发现尸体会逗留，凶手一般逃离）
    ///  - 案发后快速远离：鸭倾向（凶手逃离现场）
    static func corpseAtKillDelta() -> IdentityDelta {
        IdentityDelta(duck: 2.0, goose: -0.8, neutral: -0.3)
    }

    static func corpseMournDelta() -> IdentityDelta {
        IdentityDelta(goose: 0.6, duck: -0.4, neutral: 0.4)
    }

    static func corpseFleeDelta() -> IdentityDelta {
        IdentityDelta(duck: 1.0, goose: -0.5, neutral: 0.0)
    }

    /// 长时间未出现在任何任务点 / 全场乱逛
    static func aimlessDelta() -> IdentityDelta {
        IdentityDelta(duck: 0.3, goose: -0.2, neutral: 0.1)
    }

    /// 会议中投跳过票次数多（无目标乱投/保守）——轻微鹅倾向
    static func skipVoteDelta() -> IdentityDelta {
        IdentityDelta(goose: 0.2, duck: -0.1, neutral: 0.0)
    }
}
