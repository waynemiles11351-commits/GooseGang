# 鹅鸭杀 · AI 实时身份概率分析

分析鹅鸭杀（Goose Goose Duck）游戏画面，实时追踪**每位玩家的脚程轨迹**并推理其**身份概率（鹅 / 鸭 / 中立）**。

## 交付内容

| 目录 | 内容 | 状态 |
|---|---|---|
| `ios/` | 完整 iOS 工程（Swift + SwiftUI），在 Mac 上 `./build_ipa.sh` 一键产出 **GooseGang.ipa** | 源码可构建 |
| `pc_prototype/` | PC 实时分析原型（Python），**现在就能跑** | 可运行 |
| `docs/ARCHITECTURE.md` | 架构设计、检测/推理原理、参数说明 | 文档 |

## 两个方案怎么选

**iOS（.ipa）**——你要的形态。现实限制必须说清：

1. **iOS 系统不允许任何 App 实时叠加画面到别的 App 上**（沙盒 + ReplayKit 只提供录屏能力）。因此 iOS 版是「录屏 → 自动逐帧分析 → 身份概率与脚程报告」，不是游戏内悬浮窗。
2. `.ipa` 必须在 **macOS + Xcode** 上编译，本环境（Linux）无法直接产出可安装包。已交付**完整可构建工程**：Mac 上两条命令出包。
3. 未签名 ipa 需用爱思助手等工具重签名后安装（或填 `DEVELOPMENT_TEAM` 签名）。

**PC 原型**——真正"实时"的可行路径：捕获游戏窗口 → 画面即时叠加概率面板。Windows/Mac/Linux 都能跑。

## iOS 快速开始（Mac 上）

```bash
brew install xcodegen
cd ios
./build_ipa.sh                      # 未签名 ipa：ios/GooseGang.ipa
# 或
TEAM_ID=你的TeamID ./build_ipa.sh --sign   # 签名版
```

使用流程：iPhone 上用系统「屏幕录制」录下游戏 → 打开 App 选择录屏 → 自动分析 → 查看每位玩家身份概率 + 脚程轨迹。

## 没有 Mac / 没有电脑怎么办？（手机也可）

`build_ipa.sh` 需要 Mac，但**没有 Mac 甚至只有手机也能拿到 ipa**——构建流程已是"手机友好版"：你只需用手机浏览器做两件事：**上传 1 个压缩包**（`GooseGang-project.zip`）+ **创建 1 个配置文件**（内容在 `docs/GIT_STEPS.md` 里，直接复制粘贴），GitHub 免费云端 macOS 机器会自动编译出 ipa。完整手机操作步骤见 **`docs/GIT_STEPS.md`**。

流程：注册 GitHub → 新建仓库（Public）→ 上传 zip → 创建 `.github/workflows/build-ipa.yml`（粘贴教程里的内容）→ Actions 里点 Run workflow → 等 3~5 分钟 → Artifacts 下载 ipa → iPhone 用「牛蛙助手」自签安装（7 天有效）。

> 不想折腾 iOS 生态的话，PC 实时原型版（`pc_prototype/`）需要一台电脑运行；只想要 iOS 版则完全靠手机即可。

## PC 原型快速开始

```bash
cd pc_prototype
pip install -r requirements.txt
pip install easyocr        # 可选，识别玩家名字
python goose_analyzer.py --region 200,80,1280,720   # 框住游戏窗口
```

运行效果演示（`pc_prototype/demo_analysis.png`，合成测试画面）：

![原型演示](pc_prototype/demo_analysis.png)

## 核心原理（一分钟版）

鹅鸭杀里每个玩家头顶有**唯一名字标签** → OCR 识别名字作为稳定 ID → 追踪位置得到**脚程轨迹** → 从轨迹提取行为证据（做任务停留 / 高速绕路 / 尾随 / 尸体附近行为）→ **贝叶斯对数赔率**累加成身份概率 → softmax 归一化展示。

详见 `docs/ARCHITECTURE.md` 与项目内可视化架构图。

## 合规提示

本项目面向**学习、直播分析、单机/自定义房测试**。联网对局中使用自动身份分析属于不公平优势，可能违反游戏服务条款导致封号——请勿用于实战对局。
