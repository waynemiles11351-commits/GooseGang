#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
鹅鸭杀 · 实时身份概率分析原型（PC 版）
==========================================
核心管线：画面捕获 → 玩家检测(OCR名字标签/帧差) → 多目标追踪 → 脚程轨迹
          → 行为特征 → 贝叶斯对数赔率身份推理 → 实时可视化

用法：
  # 实时捕获屏幕（默认全屏；建议用 --region 指定游戏窗口区域）
  python goose_analyzer.py --region 100,100,1280,720

  # 分析录屏视频文件（用于调试/回看）
  python goose_analyzer.py --video game.mp4

  # 显式关闭 OCR（未安装 easyocr 时自动降级为 帧差+ID 追踪）
  python goose_analyzer.py --no-ocr --region ...

按键：Q 退出 | R 重置 | S 保存当前帧截图
依赖：pip install opencv-python numpy mss easyocr(可选)
"""
import argparse
import math
import os
import sys
import time
from collections import defaultdict

import cv2
import numpy as np

# ---------------------------------------------------------------------------
# 1. 数据模型
# ---------------------------------------------------------------------------
GOOSE, DUCK, NEUTRAL = "鹅", "鸭", "中立"
IDENTITIES = (GOOSE, DUCK, NEUTRAL)


class Player:
    __slots__ = ("name", "pos", "traj", "last_seen", "frames", "path_len",
                 "speed_samples", "task_dwell", "tail_count", "corpse_close",
                 "corpse_mourn", "scores", "color")

    def __init__(self, name, color):
        self.name = name
        self.pos = None                 # (x, y) 归一化
        self.traj = []                  # [(t, x, y)]
        self.last_seen = 0.0
        self.frames = 0
        self.path_len = 0.0
        self.speed_samples = []
        self.task_dwell = 0.0
        self.tail_count = 0
        self.corpse_close = 0
        self.corpse_mourn = 0.0
        self.scores = identity_prior()  # dict: 阵营 -> log-odds
        self.color = color

    @property
    def avg_speed(self):
        return sum(self.speed_samples) / len(self.speed_samples) if self.speed_samples else 0.0

    @property
    def net_disp(self):
        if len(self.traj) < 2:
            return 0.0
        x0, y0 = self.traj[0][1], self.traj[0][2]
        x1, y1 = self.traj[-1][1], self.traj[-1][2]
        return math.hypot(x1 - x0, y1 - y0)

    @property
    def meandering(self):
        return min(1.0, self.net_disp / max(1e-6, self.path_len))

    def prob(self):
        """softmax 归一化 -> 概率"""
        m = max(self.scores.values())
        e = {k: math.exp(v - m) for k, v in self.scores.items()}
        s = sum(e.values())
        return {k: v / s for k, v in e.items()}

    def dominant(self):
        p = self.prob()
        return max(p, key=p.get), p[max(p, key=p.get)]


# ---------------------------------------------------------------------------
# 2. 身份概率推理（与 iOS 版同一套贝叶斯对数赔率规则）
# ---------------------------------------------------------------------------
def identity_prior():
    # 常见 10 人局近似：5 鹅 / 2 鸭 / 3 中立
    return {GOOSE: math.log(0.50), DUCK: math.log(0.20), NEUTRAL: math.log(0.30)}


def apply_delta(player, d):
    for k in IDENTITIES:
        player.scores[k] += d[k]


def delta_task_dwell(seconds):
    s = min(1.0, seconds / 6.0)
    return {GOOSE: 1.2 * s, DUCK: -0.9 * s, NEUTRAL: -0.3 * s}


def delta_wander(speed, meandering):
    if speed <= 0.06:
        return {GOOSE: 0.0, DUCK: 0.0, NEUTRAL: 0.0}
    fast = min(1.0, (speed - 0.06) / 0.10)
    strength = min(1.0, fast * (0.6 + 0.4 * (1 - meandering)))
    return {GOOSE: -0.5 * strength, DUCK: 0.8 * strength, NEUTRAL: 0.1 * strength}


def delta_tail():
    return {GOOSE: -0.6, DUCK: 0.9, NEUTRAL: 0.1}


def delta_corpse_mourn():
    return {GOOSE: 0.6, DUCK: -0.4, NEUTRAL: 0.4}


def delta_corpse_flee():
    return {GOOSE: -0.5, DUCK: 1.0, NEUTRAL: 0.0}


# ---------------------------------------------------------------------------
# 3. 画面捕获源
# ---------------------------------------------------------------------------
class ScreenSource:
    """mss 实时屏幕捕获（跨平台：Win/macOS/Linux）"""

    def __init__(self, region=None):
        import mss
        self.sct = mss.mss()
        self.region = region or self.sct.monitors[1]  # 默认主显示器
        self.W = self.region["width"]
        self.H = self.region["height"]

    def frame(self):
        img = np.array(self.sct.grab(self.region))
        return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR), time.time()

    def size(self):
        return self.W, self.H


class VideoSource:
    """视频文件回放源"""

    def __init__(self, path):
        self.cap = cv2.VideoCapture(path)
        self.fps = self.cap.get(cv2.CAP_PROP_FPS) or 30
        self.t0 = time.time()

    def frame(self):
        ok, img = self.cap.read()
        if not ok:
            return None, None
        return img, self.t0 + self.cap.get(cv2.CAP_PROP_POS_FRAMES) / self.fps

    def size(self):
        return int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))


# ---------------------------------------------------------------------------
# 4. 玩家检测：OCR 名字标签（主）+ 帧差移动块（辅助）
# ---------------------------------------------------------------------------
class PlayerDetector:
    def __init__(self, use_ocr=True):
        self.use_ocr = use_ocr
        self.reader = None
        self.prev_gray = None
        if use_ocr:
            try:
                import easyocr
                self.reader = easyocr.Reader(["ch_sim", "en"], gpu=False, verbose=False)
                print("[OCR] easyocr 就绪：将识别玩家头顶名字标签")
            except Exception as e:
                print(f"[OCR] easyocr 不可用（{e}），降级为 帧差+ID 追踪")
                self.use_ocr = False
        self._name_blacklist = {"任务", "报告", "跳过", "会议", "投票", "离开", "加入",
                                "GOOSE", "DUCK", "SKIP", "REPORT", "VOTE", "鹅鸭杀"}

    def detect(self, bgr, t, size):
        """返回 [(name_or_id, body_box_xywh_normalized, conf)]"""
        W, H = size
        dets = []

        # --- A. OCR 名字标签 ---
        if self.reader is not None:
            try:
                gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
                results = self.reader.readtext(gray, detail=1, paragraph=False)
                for (box, text, conf) in results:
                    name = text.strip()
                    if not self._is_plausible_name(name, conf):
                        continue
                    xs = [p[0] for p in box]
                    ys = [p[1] for p in box]
                    x0, y0 = min(xs), min(ys)
                    x1, y1 = max(xs), max(ys)
                    # 身体框 = 名字标签正下方
                    bw, bh = (x1 - x0) * 1.6, (x1 - x0) * 1.6
                    bx, by = (x0 + x1) / 2 - bw / 2, y1
                    dets.append((name, (bx / W, by / H, bw / W, bh / H), conf))
            except Exception:
                pass

        # --- B. 帧差移动块（辅助：OCR 漏检时用 ID 占位）---
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        if self.prev_gray is not None:
            diff = cv2.absdiff(self.prev_gray, gray)
            _, mask = cv2.threshold(diff, 24, 255, cv2.THRESH_BINARY)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
            # 膨胀合并同一玩家的“名字+身体”移动区，使每帧一个玩家约一个块
            mask = cv2.dilate(mask, np.ones((9, 9), np.uint8))
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for c in contours:
                x, y, w, h = cv2.boundingRect(c)
                if w < 8 or h < 8 or w > W * 0.3 or h > H * 0.3:
                    continue
                area = w * h
                # 只保留与已有 OCR 检测不重叠的移动块
                cx, cy = x + w / 2, y + h / 2
                if any(abs(cx - (dx * W + dw * W / 2)) < dw * W and abs(cy - (dy * H + dh * H / 2)) < dh * H
                       for (_, (dx, dy, dw, dh), _) in dets):
                    continue
                dets.append((None, (x / W, y / H, w / W, h / H), 0.5))
        self.prev_gray = gray

        # 帧差移动块也交给追踪器：有名字块按名字关联，无名字块按最近邻关联/自动 ID。
        return dets

    def _is_plausible_name(self, text, conf):
        if conf < 0.3 or not (1 <= len(text) <= 14):
            return False
        up = text.upper()
        return not any(up.startswith(b.upper()) for b in self._name_blacklist)


# ---------------------------------------------------------------------------
# 5. 追踪器（名字 ID / 最近邻）与脚程引擎
# ---------------------------------------------------------------------------
class Tracker:
    def __init__(self):
        self.players = {}
        self._palette = [(255, 80, 80), (80, 160, 255), (120, 220, 120), (255, 200, 60),
                         (200, 120, 255), (80, 220, 220), (255, 140, 200), (160, 160, 160)]

    def update(self, dets, t):
        named = [d for d in dets if d[0] is not None]
        unnamed = [d for d in dets if d[0] is None]

        # OCR 名字稳定 ID（含 OCR 抖动合并：同一玩家名字变体归并）
        for name, box, conf in named:
            bx, by, bw, bh = box
            cx, cy = bx + bw / 2, by + bh / 2
            if name not in self.players:
                merged = self._find_similar(name)
                if merged is not None:
                    name = merged
            if name not in self.players:
                self.players[name] = Player(name, self._palette[len(self.players) % len(self._palette)])
            p = self.players[name]
            self._push(p, cx, cy, t)

        # 无名字移动块：贪心一对一最近邻关联；无法关联则分配自动 ID（降级模式）
        unmatched = set(self.players.keys())
        for _, box, _ in unnamed:
            bx, by, bw, bh = box
            cx, cy = bx + bw / 2, by + bh / 2
            best, best_d = None, 0.10
            for pid in unmatched:
                p = self.players[pid]
                if p.pos is None:
                    continue
                d = math.hypot(cx - p.pos[0], cy - p.pos[1])
                if d < best_d:
                    best, best_d = pid, d
            if best is not None:
                self._push(self.players[best], cx, cy, t)
                unmatched.discard(best)
            else:
                pid = self._next_id()
                p = Player(pid, self._palette[len(self.players) % len(self._palette)])
                self.players[pid] = p
                self._push(p, cx, cy, t)

    def _next_id(self):
        n = 1
        while f"P{n}" in self.players:
            n += 1
        return f"P{n}"

    def _find_similar(self, name):
        """OCR 抖动合并：与已有玩家名编辑距离 ≤ 2 且首字符相同 → 视为同一玩家"""
        for existing in self.players:
            if existing[0] == name[0] and self._edit_distance(existing, name) <= 2:
                return existing
        return None

    @staticmethod
    def _edit_distance(a, b):
        if abs(len(a) - len(b)) > 2:
            return 9
        dp = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            prev, dp[0] = dp[0], i
            for j, cb in enumerate(b, 1):
                cur = dp[j]
                dp[j] = min(dp[j] + 1, dp[j - 1] + 1, prev + (ca != cb))
                prev = cur
        return dp[-1]

    def _push(self, p, x, y, t):
        if p.pos is not None and p.frames > 0:
            dist = math.hypot(x - p.pos[0], y - p.pos[1])
            dt = max(1e-3, t - p.last_seen)
            p.speed_samples.append(dist / dt)
            if len(p.speed_samples) > 200:
                p.speed_samples.pop(0)
            p.path_len += dist
        p.pos = (x, y)
        p.last_seen = t
        p.frames += 1
        p.traj.append((t, x, y))
        if len(p.traj) > 3000:
            p.traj = p.traj[-1500:]

    def prune(self, t, keep=12.0):
        self.players = {k: v for k, v in self.players.items() if t - v.last_seen < keep}

    def tail_detect(self, threshold=0.06):
        """尾随检测：两两配对，距离近且方向一致"""
        names = list(self.players.keys())
        events = []
        for i in range(len(names)):
            for j in range(i + 1, len(names)):
                a, b = self.players[names[i]], self.players[names[j]]
                if self._is_tail(a, b, threshold):
                    events.append((names[i], names[j]))
        return events

    @staticmethod
    def _is_tail(a, b, threshold):
        n = min(len(a.traj), len(b.traj))
        if n < 8:
            return False
        ta, tb = a.traj[-n:], b.traj[-n:]
        close = sum(1 for i in range(0, n, 2)
                    if math.hypot(ta[i][1] - tb[i][1], ta[i][2] - tb[i][2]) < threshold)
        if close / ((n + 1) // 2) < 0.6:
            return False
        if n < 16:
            return False
        va = (ta[-1][1] - ta[-9][1], ta[-1][2] - ta[-9][2])
        vb = (tb[-1][1] - tb[-9][1], tb[-1][2] - tb[-9][2])
        la, lb = math.hypot(*va), math.hypot(*vb)
        if la < 0.005 or lb < 0.005:
            return False
        dot = (va[0] * vb[0] + va[1] * vb[1]) / (la * lb)
        return dot > 0.5

    def task_dwell_seconds(self, p, window=30):
        """窗口内几乎静止 -> 疑似做任务"""
        n = len(p.traj)
        if n < window:
            return 0.0
        seg = p.traj[-window:]
        x0, y0 = seg[0][1], seg[0][2]
        x1, y1 = seg[-1][1], seg[-1][2]
        moved = math.hypot(x1 - x0, y1 - y0)
        span = seg[-1][0] - seg[0][0]
        return span if moved < 0.015 else 0.0


# ---------------------------------------------------------------------------
# 6. 推理管线编排
# ---------------------------------------------------------------------------
class Analyzer:
    def __init__(self, use_ocr=True):
        self.detector = PlayerDetector(use_ocr=use_ocr)
        self.tracker = Tracker()
        self.prev_brightness = None
        self.game_phase = "未知"
        self.corpse_events = 0

    def step(self, bgr, t, size):
        dets = self.detector.detect(bgr, t, size)
        self.tracker.update(dets, t)
        self.tracker.prune(t)
        self._phase(bgr)
        self._infer(t)
        return dets

    def _phase(self, bgr):
        b = float(np.mean(cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)))
        if self.prev_brightness is not None:
            delta = self.prev_brightness - b
            if delta > 22:
                self.game_phase = "会议中"
            elif delta < -22:
                self.game_phase = "自由活动"
        self.prev_brightness = b

    def _infer(self, t):
        # 尾随
        for leader, follower in self.tracker.tail_detect():
            apply_delta(self.tracker.players[follower], delta_tail())
            apply_delta(self.tracker.players[leader], {GOOSE: 0.3, DUCK: -0.3, NEUTRAL: 0.0})
            self.tracker.players[follower].tail_count += 1

        for p in self.tracker.players.values():
            dwell = self.tracker.task_dwell_seconds(p)
            if dwell > 0:
                p.task_dwell += dwell
                apply_delta(p, delta_task_dwell(dwell))
            w = delta_wander(p.avg_speed, p.meandering)
            if any(w.values()):
                apply_delta(p, w)


# ---------------------------------------------------------------------------
# 7. 可视化
# ---------------------------------------------------------------------------
def draw(frame, analyzer, size):
    W, H = size
    players = sorted(analyzer.tracker.players.values(), key=lambda p: p.frames, reverse=True)

    # 轨迹 + 玩家
    for p in players:
        if len(p.traj) > 1:
            pts = np.array([[int(x * W), int(y * H)] for _, x, y in p.traj], np.int32)
            cv2.polylines(frame, [pts], False, p.color, 2)
        if p.pos:
            x, y = int(p.pos[0] * W), int(p.pos[1] * H)
            cv2.circle(frame, (x, y), 10, p.color, 2)
            cv2.putText(frame, p.name, (x - 30, y - 16),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            cv2.putText(frame, p.name, (x - 30, y - 16),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 1)

    # 概率条面板（右上角）
    y0 = 30
    for p in players[:8]:
        prob = p.prob()
        dom, dp = p.dominant()
        label = f"{p.name}: {dom} {dp*100:.0f}%"
        cv2.putText(frame, label, (10, y0), cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                    (255, 255, 255), 2)
        cv2.putText(frame, label, (10, y0), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 1)
        # 三色概率条
        bar_w = int(140 * dp)
        color = {"鹅": (80, 220, 120), "鸭": (80, 80, 255), "中立": (60, 200, 255)}[dom]
        cv2.rectangle(frame, (10, y0 + 8), (10 + bar_w, y0 + 14), color, -1)
        cv2.putText(frame, f"鹅{prob['鹅']*100:.0f} 鸭{prob['鸭']*100:.0f} 中立{prob['中立']*100:.0f}",
                    (10, y0 + 26), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200, 200, 200), 1)
        y0 += 44

    cv2.putText(frame, f"阶段: {analyzer.game_phase}  玩家: {len(players)}",
                (10, H - 14), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 0), 2)
    return frame


# ---------------------------------------------------------------------------
# 8. 主循环
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="鹅鸭杀实时身份概率分析原型")
    ap.add_argument("--region", help="捕获区域 x,y,w,h（如 100,100,1280,720）")
    ap.add_argument("--video", help="分析视频文件（替代实时捕获）")
    ap.add_argument("--no-ocr", action="store_true", help="关闭 OCR")
    ap.add_argument("--fps", type=float, default=10.0, help="分析帧率上限（默认 10）")
    ap.add_argument("--headless", action="store_true", help="无窗口模式（服务器/自动化），只输出报告")
    args = ap.parse_args()

    source = None
    if args.video:
        source = VideoSource(args.video)
    else:
        region = None
        if args.region:
            x, y, w, h = (int(v) for v in args.region.split(","))
            region = {"left": x, "top": y, "width": w, "height": h}
        source = ScreenSource(region)
    size = source.size()

    analyzer = Analyzer(use_ocr=not args.no_ocr)
    interval = 1.0 / max(1.0, args.fps)
    last = 0.0
    last_report = 0.0
    print("开始分析，按 Q 退出，R 重置，S 保存截图。")

    while True:
        bgr, t = source.frame()
        if bgr is None:
            print("视频播放结束。")
            break
        now = time.time()
        if now - last >= interval:
            analyzer.step(bgr, t, size)
            last = now
        if args.headless:
            if now - last_report >= 1.0:
                last_report = now
                players = sorted(analyzer.tracker.players.values(),
                                 key=lambda p: p.frames, reverse=True)
                line = " | ".join(
                    f"{p.name}:{p.dominant()[0]}{p.dominant()[1]*100:.0f}%"
                    for p in players[:6])
                print(f"  [t={t:6.2f}] {line}")
            continue
        disp = draw(bgr.copy(), analyzer, size)
        cv2.imshow("GooseGang Analyzer", disp)
        key = cv2.waitKey(1) & 0xFF
        if key in (ord("q"), 27):
            break
        elif key == ord("r"):
            analyzer = Analyzer(use_ocr=not args.no_ocr)
            print("已重置。")
        elif key == ord("s"):
            cv2.imwrite("goose_snapshot.png", disp)
            print("截图已保存 goose_snapshot.png")

    # 最终报告
    print("\n===== 身份概率报告 =====")
    for p in sorted(analyzer.tracker.players.values(), key=lambda p: p.frames, reverse=True):
        prob = p.prob()
        dom, dp = p.dominant()
        print(f"  {p.name:<16} {dom:<3} {dp*100:5.1f}%  "
              f"鹅{prob['鹅']*100:.0f}/鸭{prob['鸭']*100:.0f}/中立{prob['中立']*100:.0f}  "
              f"脚程{p.path_len:.2f} 速度{p.avg_speed:.3f} 任务停留{p.task_dwell:.1f}s 尾随{p.tail_count}")
    if not args.headless:
        cv2.destroyAllWindows()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n已退出。")
