import CoreGraphics
import Foundation

/// 单帧中检测到的一个玩家
struct DetectedPlayer {
    let name: String
    let nameBox: CGRect      // 名字标签框（归一化）
    let bodyBox: CGRect      // 玩家身体框（归一化）
    let confidence: Float
}

/// 游戏阶段（通过画面信号粗略推断）
enum GamePhase: Equatable {
    case unknown
    case exploration        // 自由活动
    case meeting            // 会议/投票
    case corpseReported     // 尸体报告动画
    case lobby              // 大厅

    var label: String {
        switch self {
        case .unknown: return "未知"
        case .exploration: return "自由活动"
        case .meeting: return "会议中"
        case .corpseReported: return "尸体报告"
        case .lobby: return "大厅"
        }
    }
}

/// 单帧观察结果：检测、阶段、尸体位置
struct FrameObservation {
    let time: TimeInterval
    let players: [DetectedPlayer]
    let phase: GamePhase
    let corpsePositions: [CGPoint]   // 归一化
}

/// 尸体事件：尸体首次出现的时刻与位置
struct CorpseEvent {
    let time: TimeInterval
    let position: CGPoint
    let witnesses: [String]   // 首次出现时在场的玩家
}
