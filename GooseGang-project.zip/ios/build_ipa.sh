#!/bin/bash
# ============================================================
# 鹅鸭杀·身份分析 iOS App 一键构建脚本
# 在 macOS（含 Xcode 15+ 与 XcodeGen）上运行，产出 GooseGang.ipa
#
# 用法:
#   ./build_ipa.sh                # 构建未签名 ipa（默认）
#   ./build_ipa.sh --sign         # 使用你的开发者证书签名后打包
#   TEAM_ID=XXXXXXXX ./build_ipa.sh --sign
#
# 说明:
#   - 未签名 ipa 无法直接在 iPhone 上安装，
#     需用「爱思助手/牛蛙助手」等工具或 Apple 开发者证书重签名。
#   - 开发调试可直接用 Xcode 打开工程运行到真机。
# ============================================================
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SIGN_MODE=false
TEAM_ID="${TEAM_ID:-}"
for arg in "$@"; do
  case "$arg" in
    --sign) SIGN_MODE=true ;;
    *) ;;
  esac
done

echo "==> [1/5] 检查工具链"
command -v xcodebuild >/dev/null 2>&1 || { echo "错误：未找到 Xcode（xcodebuild）。请先安装 Xcode 并打开一次以完成组件安装。"; exit 1; }
if ! command -v xcodegen >/dev/null 2>&1; then
  echo "   未找到 XcodeGen，尝试安装…"
  if command -v brew >/dev/null 2>&1; then
    brew install xcodegen
  else
    echo "错误：需要 XcodeGen（brew install xcodegen）。"; exit 1
  fi
fi

echo "==> [2/5] 生成 Xcode 工程"
cd "$ROOT"
xcodegen generate

echo "==> [3/5] 构建 App"
BUILD_DIR="$ROOT/build"
rm -rf "$BUILD_DIR"

if $SIGN_MODE; then
  if [ -z "$TEAM_ID" ]; then
    echo "错误：--sign 模式需要提供开发者团队 ID：TEAM_ID=XXXXXXXX ./build_ipa.sh --sign"
    exit 1
  fi
  xcodebuild \
    -project GooseGang.xcodeproj \
    -scheme GooseGang \
    -configuration Release \
    -sdk iphoneos \
    -derivedDataPath "$BUILD_DIR" \
    -destination 'generic/platform=iOS' \
    DEVELOPMENT_TEAM="$TEAM_ID" \
    CODE_SIGN_STYLE=Automatic \
    build
else
  xcodebuild \
    -project GooseGang.xcodeproj \
    -scheme GooseGang \
    -configuration Release \
    -sdk iphoneos \
    -derivedDataPath "$BUILD_DIR" \
    CODE_SIGNING_ALLOWED=NO \
    build
fi

APP_PATH="$BUILD_DIR/Build/Products/Release-iphoneos/GooseGang.app"
[ -d "$APP_PATH" ] || { echo "错误：未找到构建产物 GooseGang.app"; exit 1; }

echo "==> [4/5] 打包 .ipa"
IPA_DIR="$ROOT/ipa_stage"
rm -rf "$IPA_DIR"
mkdir -p "$IPA_DIR/Payload"
cp -R "$APP_PATH" "$IPA_DIR/Payload/"
cd "$IPA_DIR"
zip -qry "$ROOT/GooseGang.ipa" Payload
cd "$ROOT"
rm -rf "$IPA_DIR"

echo "==> [5/5] 完成"
echo "产物：$ROOT/GooseGang.ipa"
if $SIGN_MODE; then
  echo "已签名（Team: $TEAM_ID），可直接用 Apple Configurator / 描述文件分发安装。"
else
  echo "未签名 ipa。真机安装请用爱思助手等工具重签名，或在 Xcode 中直接运行调试。"
fi
