import Foundation

/// 游戏身份三大类（鹅 / 鸭 / 中立），对应鹅鸭杀的角色阵营。
enum GameIdentity: String, CaseIterable, Codable, Identifiable {
    case goose = "鹅"
    case duck = "鸭"
    case neutral = "中立"

    var id: String { rawValue }

    var colorHex: String {
        switch self {
        case .goose: return "#4CAF50"
        case .duck: return "#F44336"
        case .neutral: return "#FFB300"
        }
    }

    /// 该阵营在一局中的常见角色（用于说明，不参与推理）
    var exampleRoles: [String] {
        switch self {
        case .goose: return ["鹅", "警长", "侦探", "加拿大鹅", "网红"]
        case .duck: return ["鸭", "刺客", "间谍", "告密者", "鹈鹕"]
        case .neutral: return ["秃鹫", "呆呆鸟", "肉汁", "恋鹅鸭"]
        }
    }
}

/// 一个玩家当前的身份对数赔率分（log-odds）。
/// 推理以“对数赔率累加”进行：先验 + Σ 行为证据增量，再 softmax 归一化为概率。
struct IdentityScores: Codable {
    var goose: Double = 0
    var duck: Double = 0
    var neutral: Double = 0

    static let zero = IdentityScores()

    /// softmax 归一化得到三阵营概率（总和为 1）
    var probabilities: [GameIdentity: Double] {
        let m = max(max(goose, duck), neutral)
        let eg = exp(goose - m), ed = exp(duck - m), en = exp(neutral - m)
        let sum = eg + ed + en
        return [.goose: eg / sum, .duck: ed / sum, .neutral: en / sum]
    }

    /// 当前最可能身份
    var leading: GameIdentity {
        probabilities.max { $0.value < $1.value }!.key
    }

    /// 主导身份的概率值
    var leadingProbability: Double {
        probabilities[leading] ?? 0
    }
}

/// 一次行为证据对三个阵营对数赔率的增量。
struct IdentityDelta {
    var goose: Double = 0
    var duck: Double = 0
    var neutral: Double = 0

    static let zero = IdentityDelta()
}
