import CoreGraphics
import CoreImage
import CoreVideo
import Foundation
import Vision

/// 玩家检测器：核心思路 = 识别玩家头顶的「名字标签」。
/// 鹅鸭杀中每个玩家头顶有唯一、高对比度的名字文本（白字+描边），
/// 在地图上非常突出；名字下方即玩家身体。
/// 该方案无需训练模型，对“镜头跟随玩家移动”也鲁棒。
final class PlayerDetector {
    private let textRequest: VNRecognizeTextRequest
    private let handler: VNImageRequestHandler

    init() {
        textRequest = VNRecognizeTextRequest()
        textRequest.recognitionLevel = .accurate
        textRequest.recognitionLanguages = ["zh-Hans", "en-US"]
        textRequest.usesLanguageCorrection = false
        textRequest.minimumTextHeight = 0.012          // 过滤过小噪点文本
        handler = VNImageRequestHandler()
    }

    /// 检测一帧中的所有玩家。pixelBuffer 为 BGR(A)/BGRA 帧。
    func detect(in pixelBuffer: CVPixelBuffer) -> [DetectedPlayer] {
        guard CVPixelBufferGetWidth(pixelBuffer) > 0 else { return [] }
        let orientation = CGImagePropertyOrientation.up
        do {
            try handler.perform([textRequest], on: pixelBuffer, orientation: orientation)
        } catch {
            return []
        }

        let observations = textRequest.results ?? []
        var players: [DetectedPlayer] = []

        for obs in observations {
            guard let candidate = obs.topCandidates(1).first else { continue }
            let text = candidate.string.trimmingCharacters(in: .whitespacesAndNewlines)
            let conf = candidate.confidence

            // 名字标签过滤规则
            guard isPlausibleName(text, confidence: conf) else { continue }

            // 名字框在 Vision 坐标系中（左下原点，归一化）
            let vbox = obs.boundingBox
            // 转 UIKit 坐标系（左上原点）
            let nameBox = CGRect(x: vbox.minX,
                                 y: 1 - vbox.maxY,
                                 width: vbox.width,
                                 height: vbox.height)

            // 身体框 = 名字标签正下方的一块区域（俯视角色近似方形）
            let bodyW = nameBox.width * 1.6
            let bodyH = bodyW
            let bodyBox = CGRect(x: nameBox.midX - bodyW / 2,
                                 y: nameBox.maxY,
                                 width: bodyW,
                                 height: bodyH)

            players.append(DetectedPlayer(name: text,
                                          nameBox: nameBox,
                                          bodyBox: bodyBox,
                                          confidence: conf))
        }
        return players
    }

    /// 名字标签启发式过滤：长度、置信度、字符构成。
    private func isPlausibleName(_ text: String, confidence: Float) -> Bool {
        guard confidence > 0.35 else { return false }
        let count = text.count
        guard count >= 1 && count <= 14 else { return false }
        // 名字标签通常是白底黑字/描边短文本；排除明显的地图大字、系统提示等。
        let bannedPrefixes = ["任务", "报告", "跳过", "会议", "投票", "离开", "加入", "GOOSE", "DUCK", "SKIP", "REPORT", "VOTE"]
        let upper = text.uppercased()
        for p in bannedPrefixes where upper.hasPrefix(p.uppercased()) {
            return false
        }
        return true
    }
}

/// 画面阶段识别器：用简单的亮度/色调统计判断是否处于会议等特殊阶段。
/// 会议界面会整体压暗背景、出现大量浅色玩家头像卡片，亮度方差骤变。
struct PhaseDetector {
    func detect(pixelBuffer: CVPixelBuffer, previousBrightness: inout Double?) -> GamePhase {
        let brightness = averageBrightness(of: pixelBuffer)
        let prev = previousBrightness
        previousBrightness = brightness

        guard let prev else { return .unknown }

        // 会议/投票：亮度显著跳变（压暗）且维持
        let delta = prev - brightness
        if delta > 0.22 { return .meeting }
        if delta < -0.22 { return .exploration }
        return .unknown
    }

    private func averageBrightness(of pixelBuffer: CVPixelBuffer) -> Double {
        CVPixelBufferLockBaseAddress(pixelBuffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, .readOnly) }
        guard let base = CVPixelBufferGetBaseAddress(pixelBuffer) else { return 0 }
        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(pixelBuffer)

        // 抽稀采样：每 8 像素取一点，保证速度
        let stride = 8
        var sum: Double = 0
        var count: Double = 0
        let bpp = CVPixelBufferGetBytesPerRow(pixelBuffer) / width  // 近似字节/像素

        for y in stride(from: 0, to: height, by: stride) {
            let row = base.advanced(by: y * bytesPerRow)
            for x in stride(from: 0, to: width, by: stride) {
                let ptr = row.advanced(by: x * bpp)
                let b = ptr.load(as: UInt8.self)
                let g = ptr.advanced(by: 1).load(as: UInt8.self)
                let r = ptr.advanced(by: 2).load(as: UInt8.self)
                sum += (0.299 * Double(r) + 0.587 * Double(g) + 0.114 * Double(b))
                count += 1
            }
        }
        return count > 0 ? sum / count : 0
    }
}

/// 尸体检测：玩家身体框内出现大范围暗色/倒伏 + 周围玩家聚集时，判定为尸体。
/// 简化实现：统计画面低亮度连通块（红色报告按钮区域的红饱和度）。
struct CorpseDetector {
    /// 返回疑似尸体位置（归一化）。基于“红色高饱和小区域”启发式，
    /// 尸体报告按钮通常为红色高亮。
    func detect(pixelBuffer: CVPixelBuffer) -> [CGPoint] {
        CVPixelBufferLockBaseAddress(pixelBuffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, .readOnly) }
        guard let base = CVPixelBufferGetBaseAddress(pixelBuffer) else { return [] }
        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(pixelBuffer)
        let bpp = bytesPerRow / width

        var hits: [CGPoint] = []
        let stride = 10
        // 简易网格聚合：统计红色像素密度高的格子
        let grid = 20
        var densities = Array(repeating: 0, count: grid * grid)
        var total = 0
        for y in stride(from: 0, to: height, by: stride) {
            let row = base.advanced(by: y * bytesPerRow)
            for x in stride(from: 0, to: width, by: stride) {
                let ptr = row.advanced(by: x * bpp)
                let b = Double(ptr.load(as: UInt8.self))
                let g = Double(ptr.advanced(by: 1).load(as: UInt8.self))
                let r = Double(ptr.advanced(by: 2).load(as: UInt8.self))
                let mx = max(r, max(g, b))
                if mx > 60 && mx - min(r, min(g, b)) > 70 && r > g + 40 && r > b + 40 {
                    let gx = min(grid - 1, x * grid / width)
                    let gy = min(grid - 1, y * grid / height)
                    densities[gy * grid + gx] += 1
                }
                total += 1
            }
        }
        // 找出高密度格（≥0.35% 采样点）作为尸体候选
        for gy in 0..<grid {
            for gx in 0..<grid {
                let d = densities[gy * grid + gx]
                if d >= max(4, total / 280) {
                    let cx = (Double(gx) + 0.5) / Double(grid)
                    let cy = (Double(gy) + 0.5) / Double(grid)
                    hits.append(CGPoint(x: cx, y: cy))
                }
            }
        }
        return hits
    }
}
