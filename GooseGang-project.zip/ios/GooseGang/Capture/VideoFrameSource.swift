import AVFoundation
import CoreMedia
import CoreVideo
import Foundation

/// 视频帧源：用 AVAssetReader 逐帧解码视频，返回 CVPixelBuffer + 时间戳。
/// 分析用的录屏视频来自系统相册（用户用系统“屏幕录制”录制的游戏画面）。
final class VideoFrameSource {
    private var reader: AVAssetReader?
    private var output: AVAssetReaderTrackOutput?

    /// 打开视频，返回时长（秒）。失败抛错。
    func open(url: URL) throws -> Double {
        let asset = AVURLAsset(url: url)
        let duration = CMTimeGetSeconds(asset.duration)

        guard let track = asset.tracks(withMediaType: .video).first else {
            throw FrameError.noVideoTrack
        }
        let reader = try AVAssetReader(asset: asset)

        let settings: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: track.naturalSize.width,
            kCVPixelBufferHeightKey as String: track.naturalSize.height,
        ]
        let output = AVAssetReaderTrackOutput(track: track, outputSettings: settings)
        output.alwaysCopiesSampleData = false
        reader.add(output)
        reader.startReading()

        self.reader = reader
        self.output = output
        return duration.isFinite ? duration : 0
    }

    /// 取下一帧。读完返回 nil。
    func nextFrame() -> (CVPixelBuffer, CMTime)? {
        guard let output, reader?.status != .completed else { return nil }
        guard let sample = output.copyNextSampleBuffer() else { return nil }
        guard let buffer = CMSampleBufferGetImageBuffer(sample) else {
            return nil
        }
        let time = CMSampleBufferGetPresentationTimeStamp(sample)
        return (buffer, time)
    }

    enum FrameError: LocalizedError {
        case noVideoTrack
        var errorDescription: String? {
            switch self {
            case .noVideoTrack: return "视频中没有可解码的画面轨道"
            }
        }
    }
}
