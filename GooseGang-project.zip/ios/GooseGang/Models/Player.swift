import CoreGraphics
import Foundation

/// 轨迹采样点（位置为归一化坐标 0..1，相对视频帧）
struct TrajectoryPoint: Codable {
    let time: TimeInterval
    let x: Double
    let y: Double

    var position: CGPoint { CGPoint(x: CGFloat(x), y: CGFloat(y)) }
}

/// 玩家状态汇总：检测、追踪、脚程特征与身份概率都挂在这里。
struct Player: Identifiable {
    let id: String               // 游戏内唯一名字，由 OCR 识别
    var lastPosition: CGPoint?
    var trajectory: [TrajectoryPoint] = []
    var lastSeen: TimeInterval = 0
    var framesTracked: Int = 0

    // ---- 脚程（移动行为）统计 ----
    var totalPathLength: Double = 0        // 累计路径长度（归一化单位）
    var netDisplacement: Double = 0        // 起点→终点直线距离
    var speedSamples: [Double] = []        // 逐段速度（归一化单位/秒）

    // ---- 行为特征 ----
    var taskDwellSeconds: Double = 0       // 疑似做任务（静止在任务点）累计秒数
    var wasTaskDwell: Bool = false
    var tailCount: Int = 0                 // 尾随他人事件计数
    var corpseCloseEvents: Int = 0         // 靠近尸体事件计数
    var wasNearDeathAtKill: Bool = false   // 击杀瞬间在场
    var corpseMournSeconds: Double = 0     // 在尸体旁停留时长（围观）
    var meetingsJoined: Int = 0
    var skipVotes: Int = 0

    // ---- 推理结果 ----
    var scores = IdentityScores.zero

    var dominantIdentity: GameIdentity { scores.leading }
    var dominantProbability: Double { scores.leadingProbability }

    /// 当前平均速度
    var averageSpeed: Double {
        guard !speedSamples.isEmpty else { return 0 }
        return speedSamples.reduce(0, +) / Double(speedSamples.count)
    }

    /// 路径蜿蜒度 = 净位移 / 总路径（0~1，越小越绕）
    var meandering: Double {
        guard totalPathLength > 1e-6 else { return 1 }
        return min(1, max(0, netDisplacement / totalPathLength))
    }
}
