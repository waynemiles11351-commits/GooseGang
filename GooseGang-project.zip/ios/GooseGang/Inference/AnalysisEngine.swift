import Combine
import CoreGraphics
import Foundation
import QuartzCore

/// 分析阶段
enum AnalysisPhase: Equatable {
    case idle
    case loadingVideo
    case analyzing(progress: Double)
    case done
    case failed(String)
}

/// 分析编排引擎：逐帧执行
/// 画面 → 阶段/尸体检测 → 玩家检测(OCR) → 追踪 → 脚程特征 → 身份推理。
/// 视频逐帧处理在后台线程执行，UI 状态只在主线程发布。
final class AnalysisEngine: ObservableObject {
    @Published var players: [Player] = []
    @Published var phase: AnalysisPhase = .idle
    @Published var gamePhase: GamePhase = .unknown
    @Published var corpseEvents: [CorpseEvent] = []

    private let detector = PlayerDetector()
    private let phaseDetector = PhaseDetector()
    private let corpseDetector = CorpseDetector()
    private let tracker = PlayerTracker()
    private var previousBrightness: Double?
    private var lastCorpseCheck: TimeInterval = 0
    private var corpseAccum: [CorpseEvent] = []
    private var analysisTask: DispatchWorkItem?

    // MARK: - 入口

    /// 从视频 URL 开始分析（相册选中的录屏视频）
    func analyze(url: URL) {
        stop()
        tracker.reset()
        corpseAccum = []
        previousBrightness = nil
        lastCorpseCheck = 0
        setPhase(.loadingVideo)
        setPlayers([])
        setCorpseEvents([])

        let task = DispatchWorkItem { [weak self] in
            self?.runAnalysis(url: url)
        }
        analysisTask = task
        DispatchQueue.global(qos: .userInitiated).async(execute: task)
    }

    func stop() {
        analysisTask?.cancel()
        analysisTask = nil
    }

    // MARK: - 后台分析

    private func runAnalysis(url: URL) {
        let source = VideoFrameSource()
        do {
            let duration = try source.open(url: url)
            setPhase(.analyzing(progress: 0))

            var frameCount = 0
            var lastPublish = CACurrentMediaTime()

            while let (buffer, time) = source.nextFrame() {
                if analysisTask?.isCancelled ?? true { break }
                let t = time.seconds
                guard t.isFinite else { continue }

                // 1. 阶段与尸体检测
                let phaseNow = phaseDetector.detect(pixelBuffer: buffer, previousBrightness: &previousBrightness)
                if phaseNow != .unknown {
                    setGamePhase(phaseNow)
                }
                let corpses = corpseDetector.detect(pixelBuffer: buffer)

                // 2. 玩家检测（OCR 名字标签）
                let detections = detector.detect(in: buffer)
                let observation = FrameObservation(time: t,
                                                   players: detections,
                                                   phase: phaseNow,
                                                   corpsePositions: corpses)
                // 3. 追踪
                tracker.update(observation: observation, frameSize: frameSize(of: buffer))
                tracker.prune(olderThan: t - 15)

                // 4. 脚程特征 + 身份推理（每 5 帧执行一次，降低开销）
                if frameCount % 5 == 0 {
                    applyInference(at: t, corpses: corpses)
                }

                // 5. 尸体事件登记
                if !corpses.isEmpty && t - lastCorpseCheck > 2.0 {
                    lastCorpseCheck = t
                    let event = CorpseEvent(time: t,
                                            position: corpses[0],
                                            witnesses: witnessesNear(corpses[0]))
                    corpseAccum.append(event)
                    setCorpseEvents(corpseAccum)
                }

                frameCount += 1
                if CACurrentMediaTime() - lastPublish > 0.3 {
                    setPlayers(tracker.activePlayers)
                    lastPublish = CACurrentMediaTime()
                }

                if duration > 0 {
                    let progress = min(0.99, Double(t) / duration)
                    setPhase(.analyzing(progress: progress))
                }
            }

            setPlayers(tracker.activePlayers)
            setPhase(.done)
        } catch {
            setPhase(.failed(error.localizedDescription))
        }
    }

    // MARK: - 推理更新

    private func applyInference(at time: TimeInterval, corpses: [CGPoint]) {
        let names = Array(tracker.players.keys)

        // 尾随检测：两两配对
        for i in 0..<names.count {
            for j in (i + 1)..<names.count {
                guard let a = tracker.players[names[i]], let b = tracker.players[names[j]] else { continue }
                if TrajectoryEngine.isTail(leader: a, follower: b) {
                    mutateScores(of: names[j], delta: IdentityModel.tailDelta())      // 尾随者 → 鸭
                    mutateScores(of: names[i], delta: IdentityDelta(duck: -0.3, goose: 0.3, neutral: 0)) // 被尾随者 → 鹅
                }
            }
        }

        for name in names {
            guard var player = tracker.players[name] else { continue }

            // 任务停留
            let dwell = TrajectoryEngine.taskDwellSeconds(of: player)
            if dwell > 0 {
                player.taskDwellSeconds += dwell
                var s = player.scores
                IdentityModel.apply(IdentityModel.taskDwellDelta(seconds: dwell), to: &s)
                player.scores = s
            }

            // 高速绕路
            let wander = IdentityModel.wanderDelta(speed: player.averageSpeed, meandering: player.meandering)
            if wander.duck != 0 || wander.goose != 0 {
                var s = player.scores
                IdentityModel.apply(wander, to: &s)
                player.scores = s
            }

            // 尸体附近行为
            for corpse in corpses {
                guard let pos = player.lastPosition else { continue }
                let dist = hypot(Double(pos.x - corpse.x), Double(pos.y - corpse.y))
                if dist < 0.10 {
                    player.corpseCloseEvents += 1
                    player.corpseMournSeconds += 1
                    if player.corpseMournSeconds > 2 {
                        var s = player.scores
                        IdentityModel.apply(IdentityModel.corpseMournDelta(), to: &s)
                        player.scores = s
                    }
                }
            }
            tracker.players[name] = player
        }
    }

    private func mutateScores(of name: String, delta: IdentityDelta) {
        guard var player = tracker.players[name] else { return }
        var s = player.scores
        IdentityModel.apply(delta, to: &s)
        player.scores = s
        tracker.players[name] = player
    }

    private func witnessesNear(_ corpse: CGPoint) -> [String] {
        tracker.players.values
            .filter { p in
                guard let pos = p.lastPosition else { return false }
                return hypot(Double(pos.x - corpse.x), Double(pos.y - corpse.y)) < 0.10
            }
            .map(\.id)
    }

    // MARK: - 主线程发布

    private func setPhase(_ p: AnalysisPhase) {
        DispatchQueue.main.async { [weak self] in self?.phase = p }
    }
    private func setPlayers(_ ps: [Player]) {
        DispatchQueue.main.async { [weak self] in self?.players = ps }
    }
    private func setGamePhase(_ g: GamePhase) {
        DispatchQueue.main.async { [weak self] in self?.gamePhase = g }
    }
    private func setCorpseEvents(_ e: [CorpseEvent]) {
        DispatchQueue.main.async { [weak self] in self?.corpseEvents = e }
    }

    private func frameSize(of buffer: CVPixelBuffer) -> CGSize {
        CGSize(width: CVPixelBufferGetWidth(buffer), height: CVPixelBufferGetHeight(buffer))
    }
}
